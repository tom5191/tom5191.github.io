$(document).ready(function () {
	$('.img, p, form').hide();

	$('.copy').show();

	var sflag = true; // skills flag
	var cflag = true; // contact flag
	//Main Navigation
	$('a.about').on('click', function() {
		$('.about').fadeIn(1500);
		$('.img').fadeIn(1500);
	});

	$('a.skills').on('click', function() {
		if(sflag) {
			$( ".left-trans" ).animate({ "left": "-=150px", opacity:1 }, "slow" );
			$( ".right-trans" ).animate({ "right": "-=150px", opacity:1 }, "slow" );
			sflag = false;
			$('.p-skills').fadeIn('slow');
		}
	});

	$('a.contact').on('click', function() {
		if(cflag) {
			$('.form').fadeIn(3000);
			$('form').slideDown(1000);
			cflag = false;
		}
	});

	

	$('#about').mouseenter(function() {
		$('.about').fadeIn(1000);
		$('.img').fadeIn(1000);
	});

	$('#skills').mouseenter(function() {
		if(sflag) {
			$( ".left-trans" ).animate({ "left": "-=150px", opacity:1 }, "slow" );
			$( ".right-trans" ).animate({ "right": "-=150px", opacity:1 }, "slow" );
			sflag = false;
			$('.p-skills').fadeIn('slow');
		}
	});

	$('#contact').mouseenter(function() {
		if(cflag) {
			$('.form').fadeIn(3000);
			$('form').slideDown(1000);
			cflag = false;
		}
	});
	//end Main nav


	//mobile nav 
	$('img.navImg').on('click', function() {

		$('#sidebar').fadeToggle('slow');
	});

  /************
       FORM 
   ***********/

   	$('.success').hide();
 	$('form').on('submit', function(event) {
 		event.preventDefault();	
 		$this = $(this);
 		$.ajax( {
 			url:'assets/php/email.php',
 			type:'POST',
 			data: $this.serialize(),
 			success: function() {
	 				$this.hide();
	 				$('.success').fadeIn('slow');
	 				$('p.form').fadeOut('fast');
	  			}
 		});
		
	});



});